function taggleMode() {
    const htmlElement = document.documentElement;

   /* if (htmlElement.classList.contains("light")) {
        htmlElement.classList.remove("light");
    } else {
        htmlElement.classList.add("light");
    } */

    htmlElement.classList.toggle("light");
    const ing = 
}